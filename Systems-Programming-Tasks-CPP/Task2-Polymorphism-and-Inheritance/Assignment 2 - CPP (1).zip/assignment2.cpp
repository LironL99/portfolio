/* Assignment C++: 2
   Author: Liron Leibovich, ID: 209144773
   Author: Mishel Abramov, ID: 206421109
*/ 

#include "Menu.h"
#include <iostream>

using namespace std;

int main() {
	//simply creating a menu instance, then calling mainMenu(). the rest is inside mainMenu().
	Menu a;
	a.showMenu();
	return 0;
}






